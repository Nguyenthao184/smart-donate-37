import { useState } from "react";
import { useAuth } from "../../../store/AuthContext";
import "./Donate.scss";

const MOCK_CAMPAIGN = {
  id: 1,
  tieu_de: "Xây nhà ở cho trẻ không nơi nương tựa và nhà bán trú cho trẻ em vùng bản đi học xa của huyện Hướng Hoá",
  anh_dai_dien: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=600&h=400&fit=crop",
  so_tien_muc_tieu: 2000000000,
  so_tien_da_nhan: 133722298,
  so_luot_ung_ho: 1596,
  so_ngay_con_lai: 245,
  to_chuc: {
    ten_to_chuc: "Lý Chí Thành",
    ngan_hang: "Ngân hàng TMCP Quân Đội (MB Bank)",
    so_tai_khoan: "8062",
    chu_tai_khoan: "LY CHI THANH",
    logo_url: null,
    verified: true,
  },
};

export default function DonatePage() {
  const { user } = useAuth();
  const campaign = MOCK_CAMPAIGN;

  const [amount, setAmount] = useState("");
  const [activePreset, setActivePreset] = useState(null);
  const [anonymous, setAnonymous] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPayment, setShowPayment] = useState(false);
  const [paymentDone, setPaymentDone] = useState(false);
  const [copied, setCopied] = useState(false);

  const percent = Math.round((campaign.so_tien_da_nhan / campaign.so_tien_muc_tieu) * 100);
  const displayName = user?.name || user?.ho_ten || "Người dùng";
  const displayEmail = user?.email || "email@gmail.com";
  const orgName = campaign.to_chuc?.ten_to_chuc || "Tổ chức";

  const presets = [50000, 100000, 200000, 500000];
  const transferCode = "UH372P5XD5T4B6 UNG HO XAY DUNG NHA";

  const formatVND = (num) => num.toLocaleString("vi-VN");

  const handlePreset = (value) => {
    setActivePreset(value);
    setAmount(formatVND(value));
    setError("");
  };

  const handleAmountChange = (e) => {
    const raw = e.target.value.replace(/\D/g, "");
    if (raw) {
      setAmount(formatVND(parseInt(raw)));
    } else {
      setAmount("");
    }
    setActivePreset(null);
    setError("");
  };

  const handleAmountFocus = () => {
    if (amount === "0") setAmount("");
  };

  const handleAmountBlur = () => {
    if (!amount) setAmount("0");
  };

  const getRawAmount = () => parseInt(amount.replace(/\D/g, "")) || 0;

  const handleSubmit = () => {
    const raw = getRawAmount();
    if (raw < 10000) {
      setError("Số tiền ủng hộ tối thiểu là 10.000 VNĐ");
      return;
    }
    setError("");
    setShowPayment(true);
    setPaymentDone(false);
  };

  const handleConfirmPayment = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setPaymentDone(true);
    }, 1500);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(transferCode).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="donate-page">
      {/* Bên trái */}
      <div className="donate-left">
        <div className="donate-org">
          <div className="donate-org__avatar">{orgName[0]?.toUpperCase()}</div>
          <div className="donate-org__info">
            <span className="donate-org__label">Tiền ủng hộ được chuyển đến</span>
            <span className="donate-org__name">
              {orgName}
              {campaign.to_chuc?.verified && (
                <span className="donate-org__verified">
                  <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3"><path d="M20 6L9 17l-5-5" /></svg>
                </span>
              )}
            </span>
          </div>
        </div>

        <div className="donate-note">Bạn đang ủng hộ cho chiến dịch</div>

        <div className="donate-image">
          <img src={campaign.anh_dai_dien} alt={campaign.tieu_de} />
          <div className="donate-image__badge">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" /></svg>
            Còn {campaign.so_ngay_con_lai} ngày
          </div>
        </div>

        <h1 className="donate-title">{campaign.tieu_de}</h1>

        <div className="donate-raised">
          <div className="donate-raised__row">
            <span className="donate-raised__amount">{formatVND(campaign.so_tien_da_nhan)} VNĐ</span>
            <span className="donate-raised__percent">{percent}%</span>
          </div>
          <div className="donate-bar">
            <div className="donate-bar__fill" style={{ width: `${percent}%` }} />
          </div>
          <div className="donate-meta">
            <span>Của mục tiêu {formatVND(campaign.so_tien_muc_tieu)} VNĐ</span>
            <span>{formatVND(campaign.so_luot_ung_ho)} lượt ủng hộ</span>
          </div>
        </div>
      </div>

      {/* Bên phải */}
      <div className="donate-right">
        <div className="donate-form">
          <h2 className="donate-form__title">Thông tin ủng hộ</h2>

          <label className="donate-form__label">Nhập số tiền ủng hộ *</label>
          <div className="donate-amount-wrap">
            <input className="donate-amount-input" type="text" value={amount} onChange={handleAmountChange} onFocus={handleAmountFocus} onBlur={handleAmountBlur} placeholder="0" />
            <span className="donate-amount-unit">VNĐ</span>
          </div>

          <div className="donate-presets">
            {presets.map((val) => (
              <button key={val} className={`donate-preset ${activePreset === val ? "donate-preset--active" : ""}`} onClick={() => handlePreset(val)}>
                {formatVND(val)}
              </button>
            ))}
          </div>

          <div className="donate-section">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
            Thông tin của bạn
          </div>

          <div className="donate-field">
            <label>Họ và tên</label>
            <input type="text" value={displayName} readOnly className="donate-field__readonly" />
          </div>

          <div className="donate-field">
            <label>Email</label>
            <input type="email" value={displayEmail} readOnly className="donate-field__readonly" />
            <span className="donate-field__hint">Bạn sẽ nhận được một email xác nhận về thông tin đóng góp của mình</span>
          </div>

          <label className="donate-anon">
            <input type="checkbox" checked={anonymous} onChange={(e) => setAnonymous(e.target.checked)} />
            Ủng hộ ẩn danh
          </label>

          {error && (
            <div className="donate-error">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10" /><line x1="15" y1="9" x2="9" y2="15" /><line x1="9" y1="9" x2="15" y2="15" /></svg>
              {error}
            </div>
          )}

          <button className="donate-submit" onClick={handleSubmit}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" /></svg>
            Ủng hộ
          </button>

          <p className="donate-terms">Bằng việc ủng hộ, bạn đã đồng ý với <a href="#">Điều khoản sử dụng</a></p>
        </div>
      </div>

      {/* Modal Thanh toán */}
      {showPayment && (
        <div className="payment-overlay" onClick={(e) => e.target === e.currentTarget && setShowPayment(false)}>
          <div className="payment-modal">
            <div className="payment-modal__header">
              <span>Thanh toán</span>
              <button className="payment-modal__close" onClick={() => setShowPayment(false)}>✕</button>
            </div>
            <div className="payment-modal__body">
              <div className="payment-info">
                <div className="payment-row">
                  <span className="payment-row__label">Ngân hàng</span>
                  <span className="payment-row__value">{campaign.to_chuc.ngan_hang}</span>
                </div>
                <div className="payment-row">
                  <span className="payment-row__label">Số tài khoản thiện nguyện</span>
                  <span className="payment-row__value payment-row__value--orange">{campaign.to_chuc.so_tai_khoan}</span>
                </div>
                <div className="payment-row">
                  <span className="payment-row__label">Chủ tài khoản</span>
                  <span className="payment-row__value payment-row__value--orange">{campaign.to_chuc.chu_tai_khoan}</span>
                </div>
                <div className="payment-row">
                  <span className="payment-row__label">Số tiền</span>
                  <span className="payment-row__value payment-row__value--orange">{formatVND(getRawAmount())} VND</span>
                </div>
                <div className="payment-row">
                  <span className="payment-row__label">Nội dung chuyển khoản</span>
                  <span className="payment-row__value">
                    <span className="payment-copy">
                      <span>{transferCode}</span>
                      <button className="payment-copy__btn" onClick={handleCopy} title="Sao chép">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" /></svg>
                      </button>
                    </span>
                  </span>
                </div>
                <p className="payment-note">Vui lòng sao chép mã này vào nội dung chuyển khoản để chúng tôi nhận ra ủng hộ của bạn</p>
              </div>
              <div className="payment-qr">
                <div className="payment-qr__wrap">
                  <img src="/images/qr-acb.png" alt="QR" />
                </div>
                <div className="payment-qr__brands">
                  <span className="payment-qr__vietqr">VietQR</span>
                  <span className="payment-qr__napas">napas</span>
                </div>
                <p className="payment-qr__hint">Sử dụng ứng dụng ngân hàng MB Bank hoặc ứng dụng thanh toán hỗ trợ QR code để quét mã</p>
              </div>
            </div>
            <div className="payment-modal__footer">
              <button
                className={`payment-confirm ${paymentDone ? "payment-confirm--done" : ""}`}
                onClick={handleConfirmPayment}
                disabled={loading || paymentDone}
              >
                {paymentDone ? (
                  <>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M20 6L9 17l-5-5" /></svg>
                    Ủng hộ thành công!
                  </>
                ) : loading ? (
                  "Đang xử lý..."
                ) : (
                  <>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" /></svg>
                    Ủng hộ ngay
                  </>
                )}
              </button>
            </div>
          </div>

          {copied && <div className="payment-toast">Đã sao chép!</div>}
        </div>
      )}
    </div>
  );
}
